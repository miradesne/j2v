export const COLORS = {
  yellow: "#FFB929",
  teal: "#3FC9C8",
  blue: "#2E4EA1",
  pink: "#F39DC0",
  orange: "#F46D36"
};
