// next.config.js
module.exports = {
  images: {
    domains: ['journeytovalley.org'],
  },
}
